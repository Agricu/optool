//
//  main.m
//  optool
//  Copyright (c) 2014, Alex Zielenski
//  All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ArgumentParser/XPMArguments.h"
#import "ArgumentParser/NSString+Indenter.h"
#import <sys/ttycom.h>
#import <sys/ioctl.h>
#import "defines.h"
#import "headers.h"
#import "operations.h"
#import <spawn.h>
#import <sys/wait.h>
#import <errno.h>

// MARK: - iOS 进程调用封装 (替代 NSTask)
int runCommand(NSArray *arguments, NSString **outputString) {
    if (arguments.count == 0) return -1;
    
    const char *args[arguments.count + 1];
    for (NSUInteger i = 0; i < arguments.count; i++) {
        args[i] = [(NSString *)arguments[i] UTF8String];
    }
    args[arguments.count] = NULL;
    
    int pipefd[2];
    pipe(pipefd);
    
    posix_spawn_file_actions_t fileActions;
    posix_spawn_file_actions_init(&fileActions);
    posix_spawn_file_actions_adddup2(&fileActions, pipefd[1], STDOUT_FILENO);
    posix_spawn_file_actions_adddup2(&fileActions, pipefd[1], STDERR_FILENO);
    
    pid_t pid;
    int status = posix_spawn(&pid, args[0], &fileActions, NULL, (char *const *)args, NULL);
    
    close(pipefd[1]);
    
    if (outputString) {
        NSMutableData *outputData = [NSMutableData data];
        char buffer[1024];
        ssize_t bytesRead;
        while ((bytesRead = read(pipefd[0], buffer, sizeof(buffer))) > 0) {
            [outputData appendBytes:buffer length:bytesRead];
        }
        *outputString = [[NSString alloc] initWithData:outputData encoding:NSUTF8StringEncoding];
    }
    
    close(pipefd[0]);
    posix_spawn_file_actions_destroy(&fileActions);
    
    if (status == 0) {
        waitpid(pid, &status, 0);
        return WEXITSTATUS(status);
    } else {
        return status;
    }
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        BOOL showHelp = NO;

        // Flags
        XPMArgumentSignature *weak = [XPMArgumentSignature argumentSignatureWithFormat:@"[-w --weak]"];
        XPMArgumentSignature *resign = [XPMArgumentSignature argumentSignatureWithFormat:@"[--resign]"];
        XPMArgumentSignature *target = [XPMArgumentSignature argumentSignatureWithFormat:@"[-t --target]={1,1}"];
        XPMArgumentSignature *payload = [XPMArgumentSignature argumentSignatureWithFormat:@"[-p --payload]={1,1}"];
        XPMArgumentSignature *command = [XPMArgumentSignature argumentSignatureWithFormat:@"[-c --command]={1,1}"];
        XPMArgumentSignature *backup = [XPMArgumentSignature argumentSignatureWithFormat:@"[-b --backup]"];
        XPMArgumentSignature *output = [XPMArgumentSignature argumentSignatureWithFormat:@"[-o --output]={1,1}"];
        XPMArgumentSignature *help = [XPMArgumentSignature argumentSignatureWithFormat:@"[-h --help]"];
        
        // Actions
        XPMArgumentSignature *strip = [XPMArgumentSignature argumentSignatureWithFormat:@"[s strip]"];
        XPMArgumentSignature *restore = [XPMArgumentSignature argumentSignatureWithFormat:@"[r restore]"];
        XPMArgumentSignature *install = [XPMArgumentSignature argumentSignatureWithFormat:@"[i install]"];
        XPMArgumentSignature *rename = [XPMArgumentSignature argumentSignatureWithFormat:@"[r rename]={1,2}"];
        XPMArgumentSignature *uninstall = [XPMArgumentSignature argumentSignatureWithFormat:@"[u uninstall]"];
        XPMArgumentSignature *aslr = [XPMArgumentSignature argumentSignatureWithFormat:@"[a aslr]"];
        XPMArgumentSignature *unrestrict = [XPMArgumentSignature argumentSignatureWithFormat:@"[c unrestrict]"];
        
        [strip setInjectedSignatures:[NSSet setWithObjects:target, weak, nil]];
        [restore setInjectedSignatures:[NSSet setWithObjects:target, nil]];
        [install setInjectedSignatures:[NSSet setWithObjects:target, payload, nil]];
        [uninstall setInjectedSignatures:[NSSet setWithObjects:target, payload, nil]];
        [aslr setInjectedSignatures:[NSSet setWithObjects:target, nil]];
        [unrestrict setInjectedSignatures:[NSSet setWithObjects:target, weak, nil]];
        [rename setInjectedSignatures:[NSSet setWithObjects:target, nil]];
        
        [weak setInjectedSignatures:[NSSet setWithObjects:strip, unrestrict, nil]];
        [payload setInjectedSignatures:[NSSet setWithObjects:install, uninstall, nil]];
        [command setInjectedSignatures:[NSSet setWithObjects:install, nil]];

        XPMArgumentPackage *package = [[NSProcessInfo processInfo] xpmargs_parseArgumentsWithSignatures:@[resign, command, strip, restore, install, uninstall, output, backup, aslr, help, unrestrict, rename]];

        NSString *targetPath = [package firstObjectForSignature:target];
        if (!targetPath || [package unknownSwitches].count > 0 || [package booleanValueForSignature:help]) {
            showHelp = YES;
            goto help;
        }

        {
            NSBundle *bundle = [NSBundle bundleWithPath:targetPath];
            NSString *executablePath = [[bundle.executablePath ?: targetPath stringByExpandingTildeInPath] stringByResolvingSymlinksInPath];
            NSString *backupPath = ({
                NSString *bkp = [executablePath stringByAppendingString:@"_backup"];
                if (bundle) {
                    NSString *vers = [bundle objectForInfoDictionaryKey:(NSString *)kCFBundleVersionKey];
                    if (vers)
                        bkp = [bkp stringByAppendingPathExtension:vers];
                }
                bkp;
            });;

            NSString *outputPath = [package firstObjectForSignature:output] ?: executablePath;
            NSString *dylibPath  = [package firstObjectForSignature:payload];

            NSFileManager *manager = [NSFileManager defaultManager];

            // MARK: - 恢复备份逻辑
            if ([package booleanValueForSignature:restore]) {
                LOG("正在尝试恢复备份: %s...", backupPath.UTF8String);

                if ([manager fileExistsAtPath:backupPath]) {
                    NSError *error = nil;
                    if ([manager removeItemAtPath:executablePath error:&error]) {
                        if ([manager moveItemAtPath:backupPath toPath:executablePath error:&error]) {
                            LOG("备份恢复成功");
                            return OPErrorNone;
                        }
                        LOG("恢复失败: 无法将备份移动到目标位置");
                        return OPErrorMoveFailure;
                    }
                    LOG("恢复失败: 无法移除原文件。(%s)", error.localizedDescription.UTF8String);
                    return OPErrorRemovalFailure;
                }
                LOG("错误: 未找到该目标的备份文件");
                return OPErrorNoBackup;
            }
            
            // MARK: - 读取文件
            NSData *originalData = [NSData dataWithContentsOfFile:executablePath];
            NSMutableData *binary = originalData.mutableCopy;
            if (!binary) {
                LOG("错误: 读取文件失败");
                return OPErrorRead;
            }

            struct thin_header headers[4];
            uint32_t numHeaders = 0;
            headersFromBinary(headers, binary, &numHeaders);

            if (numHeaders == 0) {
                LOG("错误: 未找到兼容的架构");
                return OPErrorIncompatibleBinary;
            }

            // MARK: - 循环处理架构
            for (uint32_t i = 0; i < numHeaders; i++) {
                struct thin_header macho = headers[i];

                if ([package booleanValueForSignature:strip]) {
                    // 移除签名
                    if (!stripCodeSignatureFromBinary(binary, macho, [package booleanValueForSignature:weak])) {
                        LOG("警告: 未找到代码签名段");
                        return OPErrorStripFailure;
                    } else {
                        LOG("成功: 已移除代码签名");
                    }
                } else if ([package booleanValueForSignature:unrestrict]) {
                    // 移除限制
                    if (!unrestrictBinary(binary, macho, [package booleanValueForSignature:weak])) {
                        LOG("警告: 未找到 __restrict 段");
                        return OPErrorStripFailure;
                    } else {
                        LOG("成功: 已移除 __restrict 段");
                    }
                } else if ([package booleanValueForSignature:uninstall]) {
                    // 卸载 Dylib
                    if (removeLoadEntryFromBinary(binary, macho, dylibPath)) {
                        LOG("成功: 已移除所有指向 %s 的命令", dylibPath.UTF8String);
                    } else {
                        LOG("警告: 未找到指向 %s 的加载命令", dylibPath.UTF8String);
                        return OPErrorNoEntries;
                    }
                } else if ([package booleanValueForSignature:install]) {
                    // 安装 Dylib
                    NSString *lc = [package firstObjectForSignature:command];
                    uint32_t command = LC_LOAD_DYLIB;
                    if (lc) command = COMMAND(lc);
                    if (command == -1) {
                        LOG("错误: 无效的加载命令类型");
                        return OPErrorInvalidLoadCommand;
                    }

                    if (insertLoadEntryIntoBinary(dylibPath, binary, macho, command)) {
                        LOG("成功: 已为架构 %s 插入 %s 命令", CPU(macho.header.cputype), LC(command));
                    } else {
                        LOG("失败: 插入命令失败");
                        return OPErrorInsertFailure;
                    }
                } else if ([package booleanValueForSignature:aslr]) {
                    // 移除 ASLR
                    LOG("正在尝试移除 ASLR 标志...");
                    if (removeASLRFromBinary(binary, macho)) {
                        LOG("成功: 已移除 ASLR 标志");
                    } else {
                        LOG("失败: 移除 ASLR 失败");
                    }
                } else if ([package countOfSignature:rename] > 0) {
                    // 重命名
                    NSString *first = [package firstObjectForSignature:rename];
                    NSString *last  = [package lastObjectForSignature:rename];
                    if (first == last) first = nil;
                    
                    LOG("正在尝试重命名...");
                    if (renameBinary(binary, macho, first, last)) {
                        LOG("成功: 重命名完成");
                    } else {
                        LOG("失败: 重命名失败");
                    }
                } else {
                    showHelp = YES;
                    goto help;
                }
            }

            // MARK: - 备份逻辑
            if ([package booleanValueForSignature:backup]) {
                NSError *error = nil;
                LOG("正在备份文件 (%s)...", executablePath.UTF8String);
                if (![manager fileExistsAtPath:backupPath isDirectory:NULL] && ![manager copyItemAtPath:executablePath toPath:backupPath error:&error]) {
                    LOG("备份警告: %s", error.localizedDescription.UTF8String);
                    return OPErrorBackupFailure;
                }
            }

            // MARK: - 写入文件
            LOG("正在写入文件到: %s...", outputPath.UTF8String);
            if (![binary writeToFile:outputPath atomically:NO]) {
                LOG("错误: 写入文件失败 (请检查权限)");
                return OPErrorWriteFailure;
            }

            // MARK: - 重签名逻辑 (iOS 兼容版)
            if ([package booleanValueForSignature:resign]) {
                const char *resignPathC = outputPath ? outputPath.UTF8String : (bundle ? bundle.bundlePath.UTF8String : executablePath.UTF8String);
                NSString *resignPath = [NSString stringWithUTF8String:resignPathC];
                LOG("正在尝试重签名: %s...", resignPathC);
                
                NSArray *codesignArgs = @[@"/usr/bin/codesign", @"-f", @"-s", @"-", resignPath];
                NSString *outputStr = nil;
                int exitStatus = runCommand(codesignArgs, &outputStr);
                
                if (outputStr.length > 0) {
                    LOG("签名输出: %s", outputStr.UTF8String);
                }
                
                if (exitStatus == 0) {
                    LOG("成功: 重签名完成");
                } else {
                    LOG("失败: 重签名失败，正在回滚...");
                    if (![package firstObjectForSignature:output]) {
                        [originalData writeToFile:executablePath atomically:NO];
                    }
                    return OPErrorResignFailure;
                }
            }
        }

    help:
        if (showHelp) {
            struct winsize ws;
            ioctl(0, TIOCGWINSZ, &ws);

#define SHOW(SIG) LOG("%s", [[SIG xpmargs_mutableStringByIndentingToWidth:2 lineLength:ws.ws_col] UTF8String])

            LOG("optool v0.2 (汉化版)\n");
            LOG("使用方法:");
            
            SHOW(@"install -c <命令类型> -p <库路径> -t <目标文件> [-o=<输出>] [-b] [--resign] 在目标文件中插入指向库的加载命令。这可能导致某些可执行文件无法使用。");
            SHOW(@"uninstall -p <库路径> -t <目标文件> [-o=<输出>] [-b] [--resign] 从目标文件中移除所有指向该库的加载命令。这可能导致某些可执行文件无法使用。");
            SHOW(@"strip [-w] -t <目标文件> 移除二进制文件中的代码签名加载命令。");
            SHOW(@"unrestrict [-w] -t <目标文件> 移除二进制文件中的 __restrict 段。使用 -w 标志会将其重命名为 dyld 无法识别的名称（非破坏性）；否则会直接移除数据。");
            SHOW(@"restore -t <目标文件> 恢复由本工具创建的备份。");
            SHOW(@"aslr -t <目标文件> [-o=<输出>] [-b] [--resign] 如果存在，移除 Mach-O 头中的 ASLR 标志。这可能导致某些可执行文件无法使用。");
            
            LOG("\n选项:");
            SHOW(@"[-w --weak] 配合 STRIP 或 UNRESTRICT 使用，执行“弱”移除（重命名而非删除）。");
            SHOW(@"[--resign] 操作完成后尝试修复代码签名。这可能导致某些可执行文件无法使用。");
            SHOW(@"-t|--target <目标> 所有命令都需要此参数来指定要修改的文件。");
            SHOW(@"-p|--payload <库路径> INSTALL 和 UNINSTALL 命令需要此参数来指定库的路径。");
            SHOW(@"[-c --command] 指定 INSTALL 使用的加载命令类型。可选值: reexport, weak, upward, 或 load。");
            SHOW(@"[-b --backup] 将文件备份到带有后缀的路径 (格式为 _backup.版本号)。");
            SHOW(@"[-h --help] 显示此帮助信息。");
            
            LOG("\n(C) 2014 Alexander S. Zielenski. 基于 BSD 协议授权");

            return ([package booleanValueForSignature:help]) ? OPErrorNone : OPErrorInvalidArguments;
        }
    }
    
    return OPErrorNone;
}
